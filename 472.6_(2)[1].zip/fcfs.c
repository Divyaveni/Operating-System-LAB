#include <stdio.h>

void getWT(int processes[], int n,
           int bt[], int wt[])
{
    wt[0] = 0;

    for (int i = 1; i < n; i++)
    {
        wt[i] = bt[i - 1] + wt[i - 1];
    }
}

void getTAT(int processes[], int n,
            int bt[], int wt[], int tat[])
{
    for (int i = 0; i < n; i++)
    {
        tat[i] = bt[i] + wt[i];
    }
}

void getAvgTime(int processes[], int n, int burst_time[])
{
    int wt[n], tat[n], total_wt = 0, total_tat = 0;

    getWT(processes, n, burst_time, wt);

    getTAT(processes, n, burst_time, wt, tat);

    printf("Pr\tbt\twt\ttat\n");

    for (int i = 0; i < n; i++)
    {
        total_wt += wt[i];
        total_tat += tat[i];
        printf("P%d ", i);
        printf("\t%d ", burst_time[i]);
        printf("\t%d", wt[i]);
        printf("\t%d\n", tat[i]);
    }

    printf("Average waiting time = %d \n", total_wt / n);
    printf("Average turn around time = %d \n", total_tat / n);
}

int main()
{
    int processes[] = {0, 1, 2, 3};
    int n = sizeof(processes) / sizeof(processes[0]);

    int burst_time[] = {3, 5, 6, 5};

    getAvgTime(processes, n, burst_time);
    return 0;
}
