#include <stdio.h>
#include <stdbool.h>

void getWT(int processes[], int n,
           int bt[], int wt[], int quantum)
{
    int rem_bt[n];
    for (int i = 0; i < n; i++)
    {
        rem_bt[i] = bt[i];
    }

    int t = 0;

    while (1)
    {
        bool done = true;
        for (int i = 0; i < n; i++)
        {
            if (rem_bt[i] > 0)
            {
                done = false;
                if (rem_bt[i] > quantum)
                {
                    t += quantum;
                    rem_bt[i] -= quantum;
                }
                else
                {
                    t = t + rem_bt[i];
                    wt[i] = t - bt[i];
                    rem_bt[i] = 0;
                }
            }
        }

        if (done == true)
        {
            break;
        }
    }
}

void getTAT(int processes[], int n,
            int bt[], int wt[], int tat[])
{
    for (int i = 0; i < n; i++)
    {
        tat[i] = bt[i] + wt[i];
    }
}

void getAvgTime(int processes[], int n, int burst_time[],
                int quantum)
{
    int wt[n], tat[n], total_wt = 0, total_tat = 0;

    getWT(processes, n, burst_time, wt, quantum);

    getTAT(processes, n, burst_time, wt, tat);

    printf("Pr\tbt\twt\ttat\n");

    for (int i = 0; i < n; i++)
    {
        total_wt += wt[i];
        total_tat += tat[i];
        printf("P%d ", i);
        printf("\t%d ", burst_time[i]);
        printf("\t%d", wt[i]);
        printf("\t%d\n", tat[i]);
    }

    printf("Average waiting time = %d \n", total_wt / n);
    printf("Average turn around time = %d \n", total_tat / n);
}

int main()
{
    int processes[] = {0, 1, 2, 3};
    int n = sizeof(processes) / sizeof(processes[0]);

    int burst_time[] = {3, 5, 6, 5};

    int quantum = 2;
    getAvgTime(processes, n, burst_time, quantum);
    return 0;
}
